from django.apps import AppConfig


class TechcartConfig(AppConfig):
    name = 'techcart'
